# Tests manuales / ejemplos

## hash_text
Input: "hola" algoritmo sha256
Output esperado (ejemplo): 2cf24d... (comprobar con la app)

## generate_salt
- Ejecutar generate_salt() -> obtener base64 string (guardar y reusar)

## hmac_text
- Usar key "key123" y texto "hola" con sha256 -> comparar con herramienta externa si deseas.
